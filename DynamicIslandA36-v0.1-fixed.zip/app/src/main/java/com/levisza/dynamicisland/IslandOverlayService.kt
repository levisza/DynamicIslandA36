package com.levisza.dynamicisland

import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class IslandOverlayService : LifecycleService() {
    private lateinit var windowManager: WindowManager
    private var islandView: ComposeView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showIsland()
    }

    private fun showIsland() {
        if (islandView != null) return
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@IslandOverlayService)
            setContent {
                MaterialTheme {
                    IslandOverlay(onDismiss = { stopSelf() })
                }
            }
        }
        val params = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (8 * resources.displayMetrics.density).toInt()
        }
        islandView = view
        windowManager.addView(view, params)
    }

    override fun onDestroy() {
        islandView?.let {
            runCatching { windowManager.removeView(it) }
        }
        islandView = null
        super.onDestroy()
    }

}

@Composable
private fun IslandOverlay(onDismiss: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val width by animateDpAsState(
        targetValue = if (expanded) 310.dp else 126.dp,
        animationSpec = spring(dampingRatio = 0.78f, stiffness = 420f),
        label = "island-width"
    )
    val height by animateDpAsState(
        targetValue = if (expanded) 112.dp else 36.dp,
        animationSpec = spring(dampingRatio = 0.78f, stiffness = 420f),
        label = "island-height"
    )

    Column(
        modifier = Modifier
            .width(width)
            .clip(RoundedCornerShape(if (expanded) 30.dp else 24.dp))
            .background(Color.Black)
            .clickable { expanded = !expanded }
            .padding(horizontal = if (expanded) 16.dp else 12.dp, vertical = if (expanded) 13.dp else 0.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(if (expanded) 32.dp else height),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (expanded) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(30.dp).background(Color(0xFF22242B), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                        Text("♫", color = Color.White, fontSize = 18.sp)
                    }
                    Column {
                        Text("Em reprodução", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Prévia do Dynamic Island", color = Color(0xFFB9BAC2), fontSize = 10.sp)
                    }
                }
                Text("•••", color = Color.White, fontSize = 15.sp)
            } else {
                Box(Modifier.size(8.dp).background(Color(0xFF58E39B), RoundedCornerShape(50)))
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    repeat(4) { index ->
                        Box(
                            Modifier.width(3.dp).height((6 + index * 3).dp)
                                .background(Color(0xFF58E39B), RoundedCornerShape(3.dp))
                        )
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + scaleIn(initialScale = 0.94f),
            exit = fadeOut() + scaleOut(targetScale = 0.96f)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("‹", color = Color.White, fontSize = 23.sp)
                Box(Modifier.weight(1f).padding(horizontal = 12.dp).height(3.dp).background(Color(0xFF45464D), RoundedCornerShape(4.dp)))
                Text("Ⅱ", color = Color.White, fontSize = 17.sp)
                Spacer(Modifier.width(10.dp))
                Text("›", color = Color.White, fontSize = 23.sp)
            }
        }
    }
}
