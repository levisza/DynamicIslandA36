package com.levisza.dynamicisland

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFB8C7FF),
                    background = Color(0xFF08090D),
                    surface = Color(0xFF15161C)
                )
            ) {
                var overlayAllowed by remember { mutableStateOf(Settings.canDrawOverlays(this)) }
                Surface(Modifier.fillMaxSize(), color = Color(0xFF08090D)) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        Spacer(Modifier.height(18.dp))
                        Text("Dynamic Island", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Uma experiência inspirada no iOS, adaptada ao Android.", color = Color(0xFFB6B7C2), fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        IslandPreviewCard()
                        Text("CONFIGURAÇÃO", color = Color(0xFF9CA0AE), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Text(
                            if (overlayAllowed) "Permissão de sobreposição concedida" else "Permita que o app apareça sobre outros aplicativos.",
                            color = Color.White
                        )
                        Button(
                            onClick = {
                                if (!Settings.canDrawOverlays(this@MainActivity)) {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:$packageName")
                                    )
                                    startActivity(intent)
                                } else {
                                    val service = Intent(this@MainActivity, IslandOverlayService::class.java)
                                    startService(service)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Text(if (overlayAllowed) "Ativar Dynamic Island" else "Conceder permissão")
                        }
                        OutlinedButton(
                            onClick = {
                                stopService(Intent(this@MainActivity, IslandOverlayService::class.java))
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp)
                        ) { Text("Desativar ilha") }
                        Text(
                            "Versão 0.1 • Prévia visual e animações. Recursos reais de música e notificações serão adicionados nas próximas etapas.",
                            color = Color(0xFF777B89),
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refreshes the permission state when the user returns from Android Settings.
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFB8C7FF),
                background = Color(0xFF08090D),
                surface = Color(0xFF15161C)
            )) {
                MainScreen(
                    canOverlay = Settings.canDrawOverlays(this),
                    onRequestPermission = {
                        startActivity(Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        ))
                    },
                    onStart = { startService(Intent(this, IslandOverlayService::class.java)) },
                    onStop = { stopService(Intent(this, IslandOverlayService::class.java)) }
                )
            }
        }
    }
}

@Composable
private fun MainScreen(
    canOverlay: Boolean,
    onRequestPermission: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit
) {
    Surface(Modifier.fillMaxSize(), color = Color(0xFF08090D)) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Spacer(Modifier.height(18.dp))
            Text("Dynamic Island", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Uma experiência inspirada no iOS, adaptada ao Android.", color = Color(0xFFB6B7C2), fontSize = 15.sp)
            IslandPreviewCard()
            Text("CONFIGURAÇÃO", color = Color(0xFF9CA0AE), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(if (canOverlay) "Permissão de sobreposição concedida" else "Permita que o app apareça sobre outros aplicativos.", color = Color.White)
            Button(onClick = { if (canOverlay) onStart() else onRequestPermission() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Text(if (canOverlay) "Ativar Dynamic Island" else "Conceder permissão")
            }
            OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Text("Desativar ilha") }
            Text("Versão 0.1 • Prévia visual e animações. Recursos reais de música e notificações serão adicionados nas próximas etapas.", color = Color(0xFF777B89), fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun IslandPreviewCard() {
    Column(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF15161C), RoundedCornerShape(26.dp)).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("PRÉVIA", color = Color(0xFF8E93A3), fontSize = 11.sp, letterSpacing = 2.sp)
        Box(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFF262832), RoundedCornerShape(20.dp)), contentAlignment = Alignment.TopCenter) {
            Row(
                modifier = Modifier.padding(top = 12.dp).width(126.dp).height(36.dp)
                    .background(Color.Black, RoundedCornerShape(30.dp)).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(Modifier.size(9.dp).background(Color(0xFF63E6A5), RoundedCornerShape(50)))
                Box(Modifier.width(22.dp).height(5.dp).background(Color(0xFF4C4D53), RoundedCornerShape(5.dp)))
            }
        }
        Text("Cápsula compacta • toque para expandir", color = Color(0xFFB6B7C2), fontSize = 13.sp)
    }
}
