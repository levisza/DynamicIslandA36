# Dynamic Island A36 — versão 0.1

Projeto Android nativo (Kotlin + Jetpack Compose) para Samsung Galaxy A36.

## Compilar pelo GitHub sem PC
1. Crie um repositório público no GitHub chamado `DynamicIslandA36` (ou use outro nome).
2. Envie o conteúdo desta pasta para a raiz do repositório, incluindo a pasta oculta `.github`.
3. Abra a aba **Actions** e selecione **Build Dynamic Island APK**.
4. Toque em **Run workflow** se o workflow ainda não tiver sido executado.
5. Quando terminar com sucesso, abra a execução e baixe o artefato `DynamicIslandA36-debug`.
6. Extraia o ZIP do artefato e instale `app-debug.apk` no Galaxy A36.

## Permissão
Abra o app, toque em “Conceder permissão” e habilite “Aparecer sobre outros apps”. Volte ao app e toque em “Ativar Dynamic Island”. Toque na cápsula para expandir/recolher.

## Escopo atual
Protótipo visual inicial com cápsula animada e conteúdo demonstrativo. Não é uma cópia do sistema da Apple e ainda não lê sessões de mídia nem notificações reais. Isso será implementado nas próximas versões.
